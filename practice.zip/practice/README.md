# Griffin Jones Landing Page Project

## Table of Contents

## Instructions

This landing page is a creation of Griffin Jones to pass the requirements in the Udacity front-end development course. Please use the links to scroll to the necessary sections. 

To get started, open `Practice.html` 


